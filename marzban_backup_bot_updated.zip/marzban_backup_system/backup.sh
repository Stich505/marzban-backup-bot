#!/bin/bash

DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_DIR="/opt/marzban_backups"
SRC_DIR="/var/lib/marzban"
LOG_FILE="$BACKUP_DIR/backup.log"

mkdir -p "$BACKUP_DIR"

ZIP_PATH="$BACKUP_DIR/backup_$DATE.zip"
if zip -r "$ZIP_PATH" "$SRC_DIR" > /dev/null 2>>"$LOG_FILE"; then
    echo "✅ Бэкап успешно создан: $ZIP_PATH" >> "$LOG_FILE"
    curl -F document=@"$ZIP_PATH" "https://api.telegram.org/REPLACE_ME/sendDocument?chat_id=REPLACE_ID"
else
    echo "❌ Ошибка при создании бэкапа: $DATE" >> "$LOG_FILE"
    curl -F document=@"$LOG_FILE" "https://api.telegram.org/REPLACE_ME/sendDocument?chat_id=REPLACE_ID"
fi
