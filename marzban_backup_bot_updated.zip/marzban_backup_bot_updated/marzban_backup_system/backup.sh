#!/bin/bash
# Скрипт резервного копирования Marzban с использованием часового пояса Самары

# Настройки
DATE=$(TZ="Europe/Samara" date '+%Y-%m-%d_%H-%M')
BACKUP_DIR="/opt/marzban_backups"
SRC_DIR="/var/lib/marzban"
LOG_FILE="/opt/marzban_backup_system/backup.log"
ZIP_FILE="$BACKUP_DIR/backup_$DATE.zip"

BOT_TOKEN="7929597894:AAE0h_koMb_4QAPosHCljZd9WdF_Ufvkpz4"
CHAT_ID="1138858780"

# Создание директории для бэкапов
mkdir -p "$BACKUP_DIR"

# Архивация каталога с данными
if zip -r "$ZIP_FILE" "$SRC_DIR" > /dev/null 2>&1; then
    echo "$DATE ✅ Бэкап создан: $ZIP_FILE" >> "$LOG_FILE"
    
    # Отправка уведомления об успешном бэкапе через Telegram
    curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
         -d chat_id="$CHAT_ID" \
         -d text="✅ Бэкап успешно создан\n📦 Файл: backup_$DATE.zip"
    
    # Удаление старых бэкапов (оставляем только 3 последних)
    ls -tp "$BACKUP_DIR" | grep -v '/$' | tail -n +5 | while read -r file; do
        rm -f "$BACKUP_DIR/$file"
        echo "$DATE 🗑 Удалён старый бэкап: $file" >> "$LOG_FILE"
    done
else
    echo "$DATE ❌ Ошибка при создании бэкапа!" >> "$LOG_FILE"
    
    # Отправка уведомления об ошибке через Telegram
    curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
         -d chat_id="$CHAT_ID" \
         -d text="❌ Ошибка при создании бэкапа ($DATE)"
    exit 1
fi

