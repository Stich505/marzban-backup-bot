import logging
import os
import configparser
import subprocess
import zipfile

from aiogram import Bot, Dispatcher, types, executor
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import pytz

# Глобальный словарь для хранения выбора бэкапа
backup_choice_store = {}

# Загрузка конфигурации
config = configparser.ConfigParser()
config.read('/opt/marzban_telegram_bot/config.ini')

BOT_TOKEN = config['telegram']['bot_token']
CHAT_ID = config['telegram']['chat_id']
BACKUP_DIR = config['backup']['backup_dir']
SUPPORTED_FILES = {
    "geosite.dat": "/usr/local/share/xray/geosite.dat",
    "geoip.dat": "/usr/local/share/xray/geoip.dat",
    "rules.json": "/usr/local/share/xray/rules.json",
    "custom.json": "/var/lib/marzban/custom/custom.json"
}
UPLOADS_DIR = "/opt/marzban_custom_uploads"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

# Меню
main_menu = ReplyKeyboardMarkup(resize_keyboard=True)
main_menu.add(KeyboardButton("🗂 Сделать бэкап"))
main_menu.add(KeyboardButton("📦 Восстановить"))
main_menu.add(KeyboardButton("📃 Статус"))
main_menu.add(KeyboardButton("📁 Загруженные файлы"))
main_menu.add(KeyboardButton("♻️ Перезапустить Marzban"))

# Автобэкап
def run_scheduled_backup():
    subprocess.run(["/opt/marzban_backup_system/backup.sh"])

scheduler = BackgroundScheduler(timezone='Europe/Moscow')
scheduler.add_job(run_scheduled_backup, 'cron', hour=0, minute=0)
scheduler.start()

@dp.message_handler(commands=["start"])
async def start_handler(message: types.Message):
    await message.answer("📡 Бот управления Marzban", reply_markup=main_menu)

@dp.message_handler(lambda message: message.text == "🗂 Сделать бэкап")
async def manual_backup(message: types.Message):
    # Запуск скрипта создания бэкапа
    subprocess.run(["/opt/marzban_backup_system/backup.sh"])
    backups = sorted(os.listdir(BACKUP_DIR))
    if backups:
        backup_path = os.path.join(BACKUP_DIR, backups[-1])
        if os.path.exists(backup_path):
            try:
                with open(backup_path, "rb") as doc:
                    await bot.send_document(chat_id=CHAT_ID, document=doc)
                await message.answer("✅ Бэкап успешно создан и отправлен в Telegram.")
            except Exception as e:
                await message.answer(f"❌ Не удалось отправить архив: {e}")
        else:
            await message.answer("❌ Архив бэкапа не найден. Что-то пошло не так.")
    else:
        await message.answer("❌ Нет созданных бэкапов.")

@dp.message_handler(lambda message: message.text == "📦 Восстановить")
async def restore_backup(message: types.Message):
    try:
        # Получаем три последних бэкапа
        backups = sorted(os.listdir(BACKUP_DIR))[-3:]
        if not backups:
            await message.answer("❌ Нет доступных бэкапов для восстановления.")
            return
        
        # Отправляем пользователю список доступных бэкапов с номерами
        backup_list = "\n".join([f"{i+1}. {backup}" for i, backup in enumerate(backups)])
        await message.answer(f"Выберите бэкап для восстановления:\n{backup_list}\n\nОтправьте номер бэкапа (1, 2 или 3).")
        
        # Сохраняем список для этого чата
        backup_choice_store[message.chat.id] = backups
    except Exception as e:
        await message.answer(f"❌ Ошибка при подготовке восстановления: {e}")

@dp.message_handler(lambda message: message.text.isdigit() and message.chat.id in backup_choice_store)
async def choose_backup(message: types.Message):
    try:
        choice = int(message.text.strip())
        backups = backup_choice_store.get(message.chat.id, [])
        if choice < 1 or choice > len(backups):
            await message.answer("❌ Неверный выбор. Отправьте число 1, 2 или 3.")
            return
        
        selected_backup = backups[choice - 1]
        backup_file_path = os.path.join(BACKUP_DIR, selected_backup)
        
        # Распаковываем архив в /var/lib/marzban
        with zipfile.ZipFile(backup_file_path, 'r') as zip_ref:
            zip_ref.extractall('/var/lib/marzban')
        
        # Перезапускаем контейнер Marzban
        subprocess.run(["docker", "restart", "marzban-marzban-1"])
        
        await message.answer(f"✅ Бэкап {selected_backup} успешно восстановлен и контейнер перезапущен.")
        # Удаляем выбор для этого чата
        backup_choice_store.pop(message.chat.id, None)
    except ValueError:
        await message.answer("❌ Неверный ввод. Пожалуйста, отправьте число 1, 2 или 3 для выбора бэкапа.")
    except Exception as e:
        await message.answer(f"❌ Ошибка при восстановлении бэкапа: {e}")

@dp.message_handler(lambda message: message.text == "📃 Статус")
async def status_handler(message: types.Message):
    try:
        backups = sorted(os.listdir(BACKUP_DIR))[-3:]
        last = backups[-1] if backups else "Нет"
        reply = f"📊 Статус системы:\n\n🗂 Последний бэкап: {last}\n📁 Архивов в хранилище: {len(os.listdir(BACKUP_DIR))}\n🕛 Автобэкап: включён (00:00 МСК)"
        await message.answer(reply)
    except Exception as e:
        await message.answer(f"❌ Ошибка при получении статуса: {e}")

@dp.message_handler(lambda message: message.text == "♻️ Перезапустить Marzban")
async def reboot_handler(message: types.Message):
    try:
        subprocess.run(["docker", "restart", "marzban-marzban-1"])
        await message.answer("🔄 Marzban перезапущен.")
    except Exception as e:
        await message.answer(f"❌ Ошибка при перезапуске: {e}")

@dp.message_handler(lambda message: message.text == "📁 Загруженные файлы")
async def files_list(message: types.Message):
    try:
        files = os.listdir(UPLOADS_DIR) if os.path.exists(UPLOADS_DIR) else []
        if not files:
            await message.answer("❌ Файлов не загружено.")
        else:
            reply = "📁 Загруженные файлы:\n\n" + "\n".join([f"✔ {f}" for f in files])
            await message.answer(reply)
    except Exception as e:
        await message.answer(f"❌ Ошибка при получении списка файлов: {e}")

@dp.message_handler(content_types=['document'])
async def handle_file(message: types.Message):
    try:
        filename = message.document.file_name
        if filename in SUPPORTED_FILES:
            path = os.path.join(UPLOADS_DIR, filename)
            os.makedirs(UPLOADS_DIR, exist_ok=True)
            await message.document.download(destination_file=path)
            container_path = SUPPORTED_FILES[filename]
            subprocess.run(["docker", "cp", path, f"marzban-marzban-1:{container_path}"])
            subprocess.run(["docker", "restart", "marzban-marzban-1"])
            await message.answer(f"✅ Файл {filename} применён и контейнер перезапущен.")
        else:
            await message.answer(f"⚠️ Файл {filename} не поддерживается. Допустимые: {', '.join(SUPPORTED_FILES.keys())}")
    except Exception as e:
        await message.answer(f"❌ Ошибка при обработке файла: {e}")

executor.start_polling(dp)

